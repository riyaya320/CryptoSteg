#!/usr/bin/env python3
"""
Network connectivity test for CryptoSteg
"""
import socket
import subprocess
import platform

def get_network_info():
    """Get network information for troubleshooting"""
    print("🌐 CryptoSteg Network Diagnostics")
    print("=" * 50)
    
    # Get local IP addresses
    try:
        # Connect to external server to get local IP
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        print(f"📍 Primary IP Address: {local_ip}")
    except Exception as e:
        print(f"❌ Could not determine IP: {e}")
        local_ip = "127.0.0.1"
    
    # Get hostname
    hostname = socket.gethostname()
    print(f"🖥️  Hostname: {hostname}")
    
    # Test if ports are available
    def test_port(port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((local_ip, port))
            sock.close()
            return result == 0
        except:
            return False
    
    print(f"🔌 Port 5000 (Main App): {'✅ Available' if not test_port(5000) else '❌ In Use'}")
    print(f"🔌 Port 5001 (Admin): {'✅ Available' if not test_port(5001) else '❌ In Use'}")
    
    # Platform info
    print(f"💻 Platform: {platform.system()} {platform.release()}")
    
    # Network interfaces (Linux/Unix)
    if platform.system() in ['Linux', 'Darwin']:
        try:
            result = subprocess.run(['ip', 'addr', 'show'], capture_output=True, text=True)
            if result.returncode == 0:
                print("\n📡 Network Interfaces:")
                lines = result.stdout.split('\n')
                for line in lines:
                    if 'inet ' in line and '127.0.0.1' not in line:
                        print(f"   {line.strip()}")
        except:
            pass
    
    print("\n🔧 Troubleshooting Tips:")
    print("1. If using VM, set network adapter to 'Bridged Mode'")
    print("2. Check firewall settings (ufw, iptables)")
    print("3. Ensure phone is on same WiFi network")
    print(f"4. Test URL: http://{local_ip}:5000")
    print("5. For QR codes, phone must reach VM's IP address")
    
    return local_ip

if __name__ == "__main__":
    get_network_info()