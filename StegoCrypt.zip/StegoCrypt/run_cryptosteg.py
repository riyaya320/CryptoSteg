#!/usr/bin/env python3
"""
CryptoSteg - Application Launcher
Starts both main application and admin panel
"""

import subprocess
import threading
import time
import sys
import os

def run_main_app():
    """Run the main CryptoSteg application"""
    print("🔐 Starting CryptoSteg Main Application...")
    subprocess.run([sys.executable, "app.py"])

def run_admin_panel():
    """Run the admin panel"""
    print("🔧 Starting CryptoSteg Admin Panel...")
    time.sleep(2)  # Wait for main app to initialize
    subprocess.run([sys.executable, "admin.py"])

def main():
    """Launch both applications"""
    print("=" * 60)
    print("🚀 CryptoSteg - Advanced Steganography Tool")
    print("   Covert Message Delivery for Intelligence Operations")
    print("=" * 60)
    print()
    
    # Display network information
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        print(f"🌐 Your computer's IP address: {local_ip}")
        print(f"📱 Mobile access URLs:")
        print(f"   Main app: http://{local_ip}:5000")
        print(f"   Admin panel: http://{local_ip}:5001/admin")
        print()
    except Exception as e:
        print(f"⚠️  Could not determine network IP: {e}")
        print()
    
    # Check if required directories exist
    os.makedirs("uploads", exist_ok=True)
    os.makedirs("static/stego_images", exist_ok=True)
    os.makedirs("pki_data", exist_ok=True)
    
    try:
        # Start main application in a separate thread
        main_thread = threading.Thread(target=run_main_app)
        main_thread.daemon = True
        main_thread.start()
        
        # Start admin panel in main thread
        run_admin_panel()
        
    except KeyboardInterrupt:
        print("\n🛑 Shutting down CryptoSteg...")
        print("Thank you for using CryptoSteg!")

if __name__ == "__main__":
    main()